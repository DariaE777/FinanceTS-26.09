const path = require("path");

const config = {
    secret: '243Oaslhbstdfgh4O7FdaghYLDQWliuwe7YFLIAS7EDFY7iyflasi',
};

module.exports = config;