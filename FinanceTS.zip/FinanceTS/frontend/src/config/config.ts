const host = 'http://localhost:3000/api/';
export default host;