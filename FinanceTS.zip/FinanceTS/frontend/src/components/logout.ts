import {Auth} from "../auth";
import host from "../config/config";
import {DefaultResponseType} from "../types/default-response.type";

export class Logout {
    readonly openNewRoute: (arg0: string) => void;
    constructor(openNewRoute:(arg0: string) => void) {

        this.openNewRoute = openNewRoute;
        if (!localStorage.getItem(Auth.accessTokenKey) || !localStorage.getItem(Auth.refreshTokenKey)) {
            this.openNewRoute('/login');
        }
        this.logout().then();
    }

    private async logout(): Promise<boolean> {

        const response: Response = await fetch(host + 'logout', {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify({
                refreshToken: localStorage.getItem(Auth.refreshTokenKey)
            })
        });
        if (response && response.status === 200) {
            const result: DefaultResponseType | null = await response.json();
            if (result && !result.error) {
                Auth.removeTokens();
                localStorage.removeItem(Auth.userInfoKey);
                this.openNewRoute('/login');
                return true;
            }
        }
        return false;
    }
}