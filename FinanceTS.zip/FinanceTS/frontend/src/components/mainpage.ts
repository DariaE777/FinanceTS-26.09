import {Auth} from "../auth";
import {Chart, registerables} from "../../node_modules/chart.js";
import host from "../config/config";
import {GetOperationsResponseType} from "../types/get-operations-response.type";
import {DefaultResponseType} from "../types/default-response.type";
import {RefreshResponseType} from "../types/refresh-response.type";
import {DataChartType} from "../types/data-chart.type";
import {
    ChartConfiguration,
    ChartType,
    LegendElement,
    LegendOptions
} from "chart.js";
import {DataType} from "../types/data.type";
import {OptionsType} from "../types/options.type";
import {ConfigType} from "../types/config.type";
import {MarginPluginType} from "../types/margin-plugin.type";
Chart.register(...registerables);

export class MainPage {
    readonly openNewRoute: (arg0: string) => void;
    readonly token: string | null;
    readonly refreshToken: string | null;
    private param: string | null;
    readonly date: string[] = new Date().toLocaleDateString().split('.');
    readonly today: string = this.date[2] + '-' + this.date[1] + '-' + this.date[0];
    readonly dateFrom: HTMLElement | null = document.getElementById('date-from');
    readonly dateTo: HTMLElement | null = document.getElementById('date-to');
    private chart: Chart <ChartType> | null;
    private chart2: Chart <ChartType> | null;
    readonly intervalOperationsButton: HTMLElement | null = document.getElementById('interval-operations');
    readonly firstChart: HTMLElement | null = document.getElementById('myChart');
    readonly secondChart: HTMLElement | null = document.getElementById('myChart2');
    readonly todayOperations: HTMLElement | null = document.getElementById('today-operations');
    readonly weekOperations: HTMLElement | null = document.getElementById('week-operations');
    readonly monthOperations: HTMLElement | null = document.getElementById('month-operations');
    readonly yearOperations: HTMLElement | null = document.getElementById('year-operations');
    readonly allOperations: HTMLElement | null = document.getElementById('all-operations');
    constructor(openNewRoute: (arg0: string) => void) {
        this.openNewRoute = openNewRoute;
        this.param = null;
        this.chart = null;
        this.chart2 = null;
        this.token = localStorage.getItem(Auth.accessTokenKey);
        this.refreshToken = localStorage.getItem(Auth.refreshTokenKey);
        if (!this.token || !this.refreshToken) {
            this.openNewRoute('/login');
            return;
        }
        if (this.todayOperations) {
            this.todayOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'interval&dateFrom=' + this.today + '&dateTo=' + this.today));
        }
        if (this.weekOperations) {
            this.weekOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'week'));
        }
        if (this.monthOperations) {
            this.monthOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'month'));
        }
        if (this.yearOperations) {
            this.yearOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'year'));
        }
        if (this.allOperations) {
            this.allOperations.addEventListener('click', (e) => this.getOperations(e, this.param = 'all'));
        }
        if (this.intervalOperationsButton) {
            this.intervalOperationsButton.addEventListener('click', () => this.getIntervalOperations());
        }
        this.getOperations(null, this.param = 'all').then();
    }
    private getIntervalOperations(): void {
        if (this.dateFrom && this.dateTo) {
            this.dateTo.removeAttribute('disabled');
            this.dateFrom.removeAttribute('disabled');
            this.dateTo.setAttribute('type', 'date');
            this.dateFrom.setAttribute('type', 'date');
        }

        document.querySelectorAll('.btn-filter').forEach(item => {
            item.classList.remove('active');
        });
        if (this.intervalOperationsButton) {
            this.intervalOperationsButton.classList.add('active');
        }
        if (this.dateTo) {
            this.dateTo.addEventListener('input', () => this.getOperations(null, this.param = 'interval&dateFrom='
                + (this.dateFrom as HTMLInputElement).value + '&dateTo=' + (this.dateTo as HTMLInputElement).value));
        }
    }
    private async getOperations(e:MouseEvent | null, param:string): Promise<Response | undefined> {
        if (e && this.dateFrom && this.dateTo) {
            this.dateFrom.setAttribute('type', 'text');
            this.dateTo.setAttribute('type', 'text');
            this.dateTo.setAttribute('disabled', 'true');
            this.dateFrom.setAttribute('disabled', 'true');
            const buttons: NodeListOf<Element> = document.querySelectorAll('.btn-filter');
            buttons.forEach(item => {
                item.classList.remove('active');
                if (e.target) {
                    (e.target as HTMLElement).classList.add('active');
                }
            });
            if ((this.dateFrom as HTMLInputElement).value && (this.dateTo as HTMLInputElement).value) {
                (this.dateFrom as HTMLInputElement).value = '';
                (this.dateTo as HTMLInputElement).value = '';
            }
        }
        const newOperationBlocks: NodeListOf<Element> = document.querySelectorAll('div.new-operation-block');
        if (newOperationBlocks) {
            newOperationBlocks.forEach(item => {
                item.remove();
            })
        }
        if (this.token) {
            const params: RequestInit = {
                method: 'GET',
                headers: {
                    'Content-type': 'application/json',
                    'Accept': 'application/json',
                    'x-auth-token': this.token
                }
            };
            const response: Response = await fetch(host + 'operations?period=' + param, params);
            const result: GetOperationsResponseType[] | DefaultResponseType = await response.json();
            if (!result || (result as DefaultResponseType).error) {
                if (response.status === 401) {
                    const updateTokenResult: Response = await fetch(host + 'refresh', {
                        method: 'POST',
                        headers: {
                            'Content-type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({refreshToken: this.refreshToken})
                    });
                    if (updateTokenResult && updateTokenResult.status === 200) {
                        const tokens: RefreshResponseType | DefaultResponseType  = await updateTokenResult.json();
                        if (tokens && !(tokens as DefaultResponseType).error && (tokens as RefreshResponseType).tokens.accessToken && (tokens as RefreshResponseType).tokens.refreshToken) {
                            Auth.setTokens((tokens as RefreshResponseType).tokens.accessToken, (tokens as RefreshResponseType).tokens.refreshToken);
                            return response;
                        }
                    } else {
                        Auth.removeTokens();
                        localStorage.removeItem(Auth.userInfoKey);
                        this.openNewRoute('/login');
                    }
                }
                this.openNewRoute('/login');                                
            }
            await this.drawChart(result as GetOperationsResponseType[]).then();           
        }
    }

   private async drawChart(operations:GetOperationsResponseType[]): Promise<void> {
        if (this.chart) {
            this.chart.destroy();
        }
        if (this.chart2) {
            this.chart2.destroy();
        }
        //делаем margin в 20px
        const legendMargin = {
            id: 'legendMargin',
            afterInit(chart: Chart<'pie', number[], unknown>) {
                if(chart.legend) {
                    (chart.legend as {height: number}).height += 20;
                }
            }
        };
        const data1: DataType = {
            labels: [] as string[],
            datasets: [{
                label: 'Сумма в $',
                data: [],
                borderWidth: 1,
                backgroundColor: [
                    'rgb(220, 53, 69)',
                    'rgb(253, 123, 20)',
                    'rgb(255, 193, 7)',
                    'rgb(32, 201, 151)',
                    'rgb(13, 110, 253)',
                    'rgb(151,75,189)',
                ],
            },
            ],
        };
        const options1: OptionsType = {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: 'rgb(5, 44, 101)',
                        font: {
                            size: 13
                        }
                    }
                },
            }
        };
        const config1: ChartConfiguration<'pie', number[], unknown> = {
            type: 'pie',
            data: data1,
            options: options1,
            plugins: [legendMargin]
        };
        const data2: DataType = {
            labels: [] as string[],
            datasets: [{
                label: 'Сумма в $',
                data: [],
                borderWidth: 1,
                backgroundColor: [
                    'rgb(220, 53, 69)',
                    'rgb(253, 123, 20)',
                    'rgb(255, 193, 7)',
                    'rgb(32, 201, 151)',
                    'rgb(13, 110, 253)',
                    'rgb(151,75,189)',
                ],
            },
            ],
        };
        const options2: OptionsType = {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: 'rgb(5, 44, 101)',
                        font: {
                            size: 13
                        }
                    }
                },
            }
        };
        const config2: ChartConfiguration<'pie', number[], unknown> = {
            type: 'pie',
            data: data2,
            options: options2,
            plugins: [legendMargin]
        };

        const incomeArray: GetOperationsResponseType[] = operations.filter(item => item.type === 'income');
        const incomeObj: Record<string, number> = {}; //указываем тип объекта
        incomeArray.forEach(item => {
            if (!incomeObj[item.category]) {
                incomeObj[item.category] = item.amount;
            } else {
                incomeObj[item.category] += item.amount;
            }
        });
        for (const key in incomeObj) {
            if (config1.data.labels) {
                config1.data.labels.push(key);
            }
            config1.data.datasets[0].data.push(incomeObj[key]);
        }
        const expenseArray: GetOperationsResponseType[] = operations.filter(item => item.type === 'expense');
        const expenseObj: Record<string, number> = {}; //указываем тип объекта
        expenseArray.forEach(item => {
            if (!expenseObj[item.category]) {
                expenseObj[item.category] = item.amount;
            } else {
                expenseObj[item.category] += item.amount
            }
        });
        for (const key2 in expenseObj) {
            if (config2.data.labels) {
                config2.data.labels.push(key2);
            }
            config2.data.datasets[0].data.push(expenseObj[key2]);
        }

        this.chart = new Chart((this.firstChart as HTMLCanvasElement), config1 as ChartConfiguration);
        this.chart2 = new Chart((this.secondChart as HTMLCanvasElement), config2 as ChartConfiguration);
    }
}