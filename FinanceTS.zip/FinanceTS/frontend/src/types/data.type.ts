export type DataType = {
    labels: string[],
    datasets: [{
        label: string,
        data: number[],
        borderWidth: number,
        backgroundColor: string[],
    }],
}